/**
 * Testimonial Sync - Admin JavaScript
 */

(function($) {
    'use strict';
    
    var TestimonialSyncAdmin = {
        
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
        },
        
        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Add AJAX sync button handler if needed
            $(document).on('click', '.testimonial-sync-ajax', this.handleAjaxSync);
        },
        
        /**
         * Handle AJAX sync
         */
        handleAjaxSync: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var originalText = $button.text();
            
            // Disable button and show loading
            $button.prop('disabled', true).text('Syncing...');
            
            $.ajax({
                url: testimonialSyncAdmin.restUrl + 'sync',
                method: 'POST',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', testimonialSyncAdmin.nonce);
                },
                success: function(response) {
                    alert(response.message);
                    location.reload();
                },
                error: function(xhr) {
                    var message = 'Sync failed';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        message = xhr.responseJSON.message;
                    }
                    alert(message);
                },
                complete: function() {
                    $button.prop('disabled', false).text(originalText);
                }
            });
        }
        
    };
    
    // Initialize on document ready
    $(document).ready(function() {
        TestimonialSyncAdmin.init();
    });
    
})(jQuery);