# Testimonial Sync for WordPress

A WordPress plugin that syncs testimonials from your Laravel app and displays them with customizable templates.

## Features

- 🔄 **Automatic Syncing** - Scheduled background syncing via WP Cron
- 🎨 **Flexible Display** - Multiple layout options (list, grid)
- 🛠️ **Developer-Friendly** - Easy template overrides and helper functions
- 📸 **Headshot Support** - Automatically downloads and stores author photos
- ⭐ **Rating System** - Display star ratings for testimonials
- 🎯 **Featured Testimonials** - Mark testimonials as featured
- 🔌 **REST API** - Access testimonials via REST endpoints
- 📝 **Custom Post Type** - Full WordPress integration with searchable content

## Installation

1. Upload the `testimonial-sync` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **Testimonials > Sync Settings** to configure your API endpoint

## Configuration

### API Setup

1. Navigate to **Testimonials > Sync Settings**
2. Enter your Laravel API endpoint URL
3. (Optional) Add your API key for authentication
4. Configure sync frequency (hourly, twice daily, daily)
5. Click **Save Settings**

### Laravel API Format

Your Laravel API should return JSON in one of these formats:

#### Format 1: Simple Array
```json
[
  {
    "id": 1,
    "title": "Great Service!",
    "content": "This was an amazing experience...",
    "author_name": "John Doe",
    "author_title": "CEO",
    "company": "Acme Corp",
    "rating": 5,
    "date_given": "2024-01-15",
    "featured": true,
    "headshot_url": "https://example.com/images/john.jpg"
  }
]
```

#### Format 2: Laravel Pagination
```json
{
  "data": [
    {
      "id": 1,
      "title": "Great Service!",
      ...
    }
  ],
  "current_page": 1,
  "total": 10
}
```

#### Format 3: Named Key
```json
{
  "testimonials": [
    {
      "id": 1,
      "title": "Great Service!",
      ...
    }
  ]
}
```

### Required Fields

- `id` - Unique identifier from your Laravel app

### Optional Fields

- `title` - Testimonial headline
- `content` - Main testimonial text
- `author_name` - Person who gave the testimonial
- `author_title` - Their job title
- `company` - Company name
- `rating` - Number from 1-5
- `date_given` - Date the testimonial was given
- `featured` - Boolean for featured status
- `headshot_url` - URL to author's photo

## Usage

### Shortcodes

Display testimonials anywhere using shortcodes:

```php
// Basic usage
[testimonials]

// Show only featured testimonials
[testimonials featured="true"]

// Limit to 5 testimonials
[testimonials limit="5"]

// Grid layout with 3 columns
[testimonials layout="grid" columns="3"]

// Combine options
[testimonials featured="true" limit="6" layout="grid" columns="2"]
```

#### Shortcode Parameters

- `limit` - Number of testimonials to show (default: 10)
- `featured` - Show only featured testimonials (true/false)
- `layout` - Display layout: `list` or `grid` (default: list)
- `columns` - Number of columns for grid layout (default: 3)
- `order` - Sort order: `ASC` or `DESC` (default: DESC)
- `orderby` - Sort by: `date`, `title`, `rand` (default: date)

### Template Tags

Use these functions in your theme templates:

```php
// Get testimonials
$testimonials = testimonial_get_testimonials();
if ($testimonials->have_posts()) {
    while ($testimonials->have_posts()) {
        $testimonials->the_post();
        
        // Display testimonial data
        testimonial_author_name();
        testimonial_author_title();
        testimonial_company();
        testimonial_rating();
        testimonial_headshot('thumbnail');
        testimonial_author_byline();
        
        // Check if featured
        if (testimonial_is_featured()) {
            echo 'Featured!';
        }
    }
    wp_reset_postdata();
}

// Get only featured testimonials
$featured = testimonial_get_featured(5);
```

### Helper Functions

```php
// Get data (returns values)
testimonial_get_author_name($post_id);
testimonial_get_author_title($post_id);
testimonial_get_company($post_id);
testimonial_get_rating($post_id);
testimonial_get_date_given($post_id);
testimonial_get_headshot_url('thumbnail', $post_id);
testimonial_get_author_byline($post_id);
testimonial_is_featured($post_id);

// Display data (echoes values)
testimonial_author_name();
testimonial_author_title();
testimonial_company();
testimonial_rating(); // Outputs star rating HTML
testimonial_headshot('medium');
testimonial_author_byline();
testimonial_date_given('F j, Y');
```

## Template Overrides

Override templates by copying them to your theme:

```
your-theme/
  testimonial-sync/
    testimonials-list.php
    testimonials-grid.php
    single-testimonial.php
```

### Creating Custom Layouts

1. Copy `templates/testimonials-list.php` to your theme
2. Rename it (e.g., `testimonials-custom.php`)
3. Modify the template
4. Use it: `[testimonials layout="custom"]`

## Hooks & Filters

### Actions

```php
// After testimonial is saved
do_action('testimonial_sync_testimonial_saved', $post_id, $testimonial_data);

// After sync completes
do_action('testimonial_sync_completed', $synced_count, $error_count);

// Logging
do_action('testimonial_sync_log', $message, $level);
```

### Filters

```php
// Modify API request arguments
add_filter('testimonial_sync_api_request_args', function($args) {
    $args['timeout'] = 60;
    return $args;
});

// Modify API response data
add_filter('testimonial_sync_api_response_data', function($data) {
    // Transform data if needed
    return $data;
});

// Modify post data before saving
add_filter('testimonial_sync_post_data', function($post_data, $testimonial_data) {
    // Customize how posts are created
    return $post_data;
}, 10, 2);

// Modify query arguments
add_filter('testimonial_sync_query_args', function($args, $atts) {
    // Customize testimonial queries
    return $args;
}, 10, 2);

// Handle custom API response structures
add_filter('testimonial_sync_extract_testimonials', function($data) {
    if (isset($data['custom_key'])) {
        return $data['custom_key'];
    }
    return $data;
});
```

## REST API

Access testimonials via REST API:

```
GET /wp-json/testimonial-sync/v1/testimonials
GET /wp-json/testimonial-sync/v1/testimonials?featured=1&per_page=5
POST /wp-json/testimonial-sync/v1/sync (requires authentication)
```

## Manual Sync

Sync testimonials manually:

1. Go to **Testimonials > Sync Settings**
2. Click **Sync Now** button
3. Or use WP-CLI: `wp cron event run testimonial_sync_cron_hook`

## Sync Status

View sync status and logs:

1. Go to **Testimonials > Sync Status**
2. View last sync time, status, and count
3. Check sync logs for any errors

## Styling

The plugin includes default CSS that can be customized:

- Override `assets/css/frontend.css` in your theme
- Or add custom CSS through your theme
- All elements have semantic class names for easy targeting

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- Laravel API endpoint returning JSON

## Support

For issues or feature requests, please contact support or submit an issue.

## License

GPL v2 or later

## Changelog

### 1.0.0
- Initial release
- Automatic syncing with WP Cron
- List and grid layouts
- Template override system
- REST API endpoints
- Helper functions for developers