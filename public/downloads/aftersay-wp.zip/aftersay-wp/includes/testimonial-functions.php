<?php

/**
 * Helper functions for accessing testimonial data
 * These functions can be used by developers in custom templates
 */

/**
 * Get testimonial author name
 */
function testimonial_get_author_name($post_id = null)
{
    if (! $post_id) {
        $post_id = get_the_ID();
    }

    return get_post_meta($post_id, '_testimonial_author_name', true);
}

/**
 * Display testimonial author name
 */
function testimonial_author_name($post_id = null)
{
    echo esc_html(testimonial_get_author_name($post_id));
}

/**
 * Get testimonial author title
 */
function testimonial_get_author_title($post_id = null)
{
    if (! $post_id) {
        $post_id = get_the_ID();
    }

    return get_post_meta($post_id, '_testimonial_author_title', true);
}

/**
 * Display testimonial author title
 */
function testimonial_author_title($post_id = null)
{
    echo esc_html(testimonial_get_author_title($post_id));
}

/**
 * Get testimonial company
 */
function testimonial_get_company($post_id = null)
{
    if (! $post_id) {
        $post_id = get_the_ID();
    }

    return get_post_meta($post_id, '_testimonial_company', true);
}

/**
 * Display testimonial company
 */
function testimonial_company($post_id = null)
{
    echo esc_html(testimonial_get_company($post_id));
}

/**
 * Get testimonial rating
 */
function testimonial_get_rating($post_id = null)
{
    if (! $post_id) {
        $post_id = get_the_ID();
    }

    return get_post_meta($post_id, '_testimonial_rating', true);
}

/**
 * Display testimonial rating
 */
function testimonial_rating($post_id = null)
{
    $rating = testimonial_get_rating($post_id);
    if ($rating) {
        echo Testimonial_Display::get_rating_html($rating);
    }
}

/**
 * Check if testimonial is featured
 */
function testimonial_is_featured($post_id = null)
{
    if (! $post_id) {
        $post_id = get_the_ID();
    }

    return (bool) get_post_meta($post_id, '_testimonial_featured', true);
}

/**
 * Get testimonial date given
 */
function testimonial_get_date_given($post_id = null)
{
    if (! $post_id) {
        $post_id = get_the_ID();
    }

    return get_post_meta($post_id, '_testimonial_date_given', true);
}

/**
 * Display testimonial date given
 */
function testimonial_date_given($format = null, $post_id = null)
{
    $date = testimonial_get_date_given($post_id);
    if ($date) {
        if ($format) {
            echo esc_html(date_i18n($format, strtotime($date)));
        } else {
            echo esc_html($date);
        }
    }
}

/**
 * Get testimonial headshot URL
 */
function testimonial_get_headshot_url($size = 'thumbnail', $post_id = null)
{
    if (! $post_id) {
        $post_id = get_the_ID();
    }

    return get_the_post_thumbnail_url($post_id, $size);
}

/**
 * Display testimonial headshot
 */
function testimonial_headshot($size = 'thumbnail', $attr = [], $post_id = null)
{
    if (! $post_id) {
        $post_id = get_the_ID();
    }

    if (! isset($attr['class'])) {
        $attr['class'] = 'testimonial-headshot';
    }

    $author_name = testimonial_get_author_name($post_id);
    if ($author_name && ! isset($attr['alt'])) {
        $attr['alt'] = sprintf(__('%s headshot', 'testimonial-sync'), $author_name);
    }

    echo get_the_post_thumbnail($post_id, $size, $attr);
}

/**
 * Get author byline (Name, Title at Company)
 */
function testimonial_get_author_byline($post_id = null)
{
    if (! $post_id) {
        $post_id = get_the_ID();
    }

    $name = testimonial_get_author_name($post_id);
    $title = testimonial_get_author_title($post_id);
    $company = testimonial_get_company($post_id);

    $byline = $name;

    if ($title && $company) {
        $byline .= ', '.$title.' '.__('at', 'testimonial-sync').' '.$company;
    } elseif ($title) {
        $byline .= ', '.$title;
    } elseif ($company) {
        $byline .= ', '.$company;
    }

    return $byline;
}

/**
 * Display author byline
 */
function testimonial_author_byline($post_id = null)
{
    echo esc_html(testimonial_get_author_byline($post_id));
}

/**
 * Get all testimonials
 */
function testimonial_get_testimonials($args = [])
{
    $defaults = [
        'post_type' => Testimonial_Post_Type::POST_TYPE,
        'posts_per_page' => -1,
        'orderby' => 'date',
        'order' => 'DESC',
    ];

    $args = wp_parse_args($args, $defaults);

    return new WP_Query($args);
}

/**
 * Get featured testimonials
 */
function testimonial_get_featured($limit = -1)
{
    return testimonial_get_testimonials([
        'posts_per_page' => $limit,
        'meta_query' => [
            [
                'key' => '_testimonial_featured',
                'value' => '1',
            ],
        ],
    ]);
}
