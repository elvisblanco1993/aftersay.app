<?php

/**
 * Admin interface and settings controller
 */
class Testimonial_Admin
{
    /**
     * Constructor to include necessary admin files.
     */
    public function __construct()
    {
        // Include separate files for settings and page rendering
        include_once __DIR__.'/admin/class-testimonial-settings.php';
        include_once __DIR__.'/admin/class-testimonial-settings-page.php';
        include_once __DIR__.'/admin/class-testimonial-status-page.php';
    }

    /**
     * Add menu pages
     */
    public function add_menu_pages()
    {
        // Settings page
        add_submenu_page(
            'edit.php?post_type=testimonial',
            __('Sync Settings', 'testimonial-sync'),
            __('Sync Settings', 'testimonial-sync'),
            'manage_options',
            'testimonial-sync-settings',
            [new Testimonial_Settings_Page, 'render'] // Delegated to separate class
        );

        // Sync status page
        add_submenu_page(
            'edit.php?post_type=testimonial',
            __('Sync Status', 'testimonial-sync'),
            __('Sync Status', 'testimonial-sync'),
            'manage_options',
            'testimonial-sync-status',
            [new Testimonial_Status_Page, 'render'] // Delegated to separate class
        );
    }

    /**
     * Register settings (Delegated to separate class)
     */
    public function register_settings()
    {
        $settings = new Testimonial_Settings;
        $settings->register_settings();
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook)
    {
        // Only load on our plugin pages
        if (strpos($hook, 'testimonial') === false) {
            return;
        }

        wp_enqueue_style(
            'testimonial-sync-admin',
            TESTIMONIAL_SYNC_PLUGIN_URL.'assets/css/admin.css',
            [],
            TESTIMONIAL_SYNC_VERSION
        );

        wp_enqueue_script(
            'testimonial-sync-admin',
            TESTIMONIAL_SYNC_PLUGIN_URL.'assets/js/admin.js',
            ['jquery'],
            TESTIMONIAL_SYNC_VERSION,
            true
        );

        wp_localize_script('testimonial-sync-admin', 'testimonialSyncAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'restUrl' => rest_url('testimonial-sync/v1/'),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);
    }
}
