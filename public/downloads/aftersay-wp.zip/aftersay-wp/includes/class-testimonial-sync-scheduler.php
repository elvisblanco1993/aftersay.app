<?php

/**
 * Handles scheduled syncing of testimonials
 */
class Testimonial_Sync_Scheduler
{
    /**
     * Sync testimonials from API
     */
    public function sync_testimonials()
    {
        $api = new Testimonial_API;

        // Log sync start
        $this->log('Starting testimonial sync');

        // Fetch testimonials from API
        $result = $api->fetch_testimonials();

        if (is_wp_error($result)) {
            $this->log('Sync failed: '.$result->get_error_message(), 'error');
            update_option('testimonial_sync_last_error', $result->get_error_message());
            update_option('testimonial_sync_last_sync_status', 'failed');

            return $result;
        }

        // Handle different response structures
        $testimonials = $this->extract_testimonials($result);

        if (empty($testimonials)) {
            $this->log('No testimonials found in API response');
            update_option('testimonial_sync_last_sync_status', 'success');
            update_option('testimonial_sync_last_sync_count', 0);
            update_option('testimonial_sync_last_sync_time', current_time('mysql'));

            return;
        }

        $synced_count = 0;
        $error_count = 0;

        foreach ($testimonials as $testimonial_data) {
            $result = $api->save_testimonial($testimonial_data);

            if (is_wp_error($result)) {
                $error_count++;
                $this->log('Failed to save testimonial: '.$result->get_error_message(), 'error');
            } else {
                $synced_count++;
            }
        }

        // Update sync status
        update_option('testimonial_sync_last_sync_time', current_time('mysql'));
        update_option('testimonial_sync_last_sync_count', $synced_count);
        update_option('testimonial_sync_last_sync_status', $error_count > 0 ? 'partial' : 'success');

        if ($error_count > 0) {
            update_option('testimonial_sync_last_error', sprintf(
                __('%d testimonials synced, %d errors', 'testimonial-sync'),
                $synced_count,
                $error_count
            ));
        } else {
            delete_option('testimonial_sync_last_error');
        }

        $this->log(sprintf('Sync completed: %d synced, %d errors', $synced_count, $error_count));

        do_action('testimonial_sync_completed', $synced_count, $error_count);

        return [
            'synced' => $synced_count,
            'errors' => $error_count,
        ];
    }

    /**
     * Extract testimonials from API response
     * Handles different response structures
     */
    private function extract_testimonials($data)
    {
        // If data is directly an array of testimonials
        if (isset($data[0]) && is_array($data[0])) {
            return $data;
        }

        // If data has a 'data' key (Laravel pagination)
        if (isset($data['data']) && is_array($data['data'])) {
            return $data['data'];
        }

        // If data has a 'testimonials' key
        if (isset($data['testimonials']) && is_array($data['testimonials'])) {
            return $data['testimonials'];
        }

        // Allow filtering for custom structures
        return apply_filters('testimonial_sync_extract_testimonials', $data);
    }

    /**
     * Manual sync via AJAX or REST API
     */
    public function manual_sync()
    {
        $result = $this->sync_testimonials();

        if (is_wp_error($result)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $result->get_error_message(),
            ], 500);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => sprintf(
                __('Successfully synced %d testimonials', 'testimonial-sync'),
                $result['synced']
            ),
            'data' => $result,
        ], 200);
    }

    /**
     * Log sync activity
     */
    private function log($message, $level = 'info')
    {
        // Store in option for admin display
        $logs = get_option('testimonial_sync_logs', []);

        $logs[] = [
            'time' => current_time('mysql'),
            'level' => $level,
            'message' => $message,
        ];

        // Keep only last 50 logs
        $logs = array_slice($logs, -50);

        update_option('testimonial_sync_logs', $logs);

        // Also use WP error_log if WP_DEBUG is on
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[Testimonial Sync] '.$message);
        }

        do_action('testimonial_sync_log', $message, $level);
    }

    /**
     * Clear sync logs
     */
    public function clear_logs()
    {
        delete_option('testimonial_sync_logs');
    }
}
