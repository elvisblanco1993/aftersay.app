<?php

/**
 * Frontend display and templates
 */
class Testimonial_Display
{
    /**
     * Enqueue frontend assets
     */
    public function enqueue_frontend_assets()
    {
        wp_enqueue_style(
            'testimonial-sync-frontend',
            TESTIMONIAL_SYNC_PLUGIN_URL.'assets/css/frontend.css',
            [],
            TESTIMONIAL_SYNC_VERSION
        );

        wp_enqueue_script(
            'testimonial-sync-frontend',
            TESTIMONIAL_SYNC_PLUGIN_URL.'assets/js/frontend.js',
            ['jquery'],
            TESTIMONIAL_SYNC_VERSION,
            true
        );
    }

    /**
     * Shortcode handler
     *
     * Usage: [testimonials limit="5" featured="true" layout="grid"]
     */
    public function shortcode($atts)
    {
        $atts = shortcode_atts([
            'limit' => 10,
            'featured' => false,
            'layout' => 'list', // list, grid, slider
            'columns' => 3,
            'order' => 'DESC',
            'orderby' => 'date',
        ], $atts, 'testimonials');

        // Build query args
        $query_args = [
            'post_type' => Testimonial_Post_Type::POST_TYPE,
            'posts_per_page' => intval($atts['limit']),
            'order' => $atts['order'],
            'orderby' => $atts['orderby'],
        ];

        // Filter by featured
        if ($atts['featured'] === 'true' || $atts['featured'] === '1') {
            $query_args['meta_query'] = [
                [
                    'key' => '_testimonial_featured',
                    'value' => '1',
                ],
            ];
        }

        // Allow filtering
        $query_args = apply_filters('testimonial_sync_query_args', $query_args, $atts);

        $query = new WP_Query($query_args);

        if (! $query->have_posts()) {
            return '<p class="testimonials-none">'.__('No testimonials found.', 'testimonial-sync').'</p>';
        }

        ob_start();

        // Load template based on layout
        $template = $this->locate_template("testimonials-{$atts['layout']}.php");

        if ($template) {
            include $template;
        } else {
            // Fallback to default list template
            include $this->locate_template('testimonials-list.php');
        }

        wp_reset_postdata();

        return ob_get_clean();
    }

    /**
     * Locate template file
     * Checks theme first, then plugin
     */
    public function locate_template($template_name)
    {
        // Check theme directory first
        $theme_template = locate_template([
            'testimonial-sync/'.$template_name,
            $template_name,
        ]);

        if ($theme_template) {
            return $theme_template;
        }

        // Check plugin templates directory
        $plugin_template = TESTIMONIAL_SYNC_PLUGIN_DIR.'templates/'.$template_name;

        if (file_exists($plugin_template)) {
            return $plugin_template;
        }

        return false;
    }

    /**
     * Template loader for single testimonial pages
     */
    public function template_loader($template)
    {
        if (is_singular(Testimonial_Post_Type::POST_TYPE)) {
            $custom_template = $this->locate_template('single-testimonial.php');
            if ($custom_template) {
                return $custom_template;
            }
        }

        if (is_post_type_archive(Testimonial_Post_Type::POST_TYPE)) {
            $custom_template = $this->locate_template('archive-testimonial.php');
            if ($custom_template) {
                return $custom_template;
            }
        }

        return $template;
    }

    /**
     * Get testimonial rating HTML
     */
    public static function get_rating_html($rating, $max_rating = 5)
    {
        if (empty($rating)) {
            return '';
        }

        $rating = absint($rating);
        $max_rating = absint($max_rating);

        $html = '<div class="testimonial-rating" aria-label="'.sprintf(__('Rating: %d out of %d', 'testimonial-sync'), $rating, $max_rating).'">';

        for ($i = 1; $i <= $max_rating; $i++) {
            if ($i <= $rating) {
                $html .= '<span class="star star-filled">★</span>';
            } else {
                $html .= '<span class="star star-empty">☆</span>';
            }
        }

        $html .= '</div>';

        return $html;
    }
}
