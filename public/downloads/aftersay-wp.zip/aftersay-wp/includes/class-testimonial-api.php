<?php

/**
 * API communication with Laravel app
 */
class Testimonial_API
{
    /**
     * Get API settings
     */
    private function get_settings()
    {
        return [
            'endpoint' => get_option('testimonial_sync_api_endpoint', ''),
            'api_key' => get_option('testimonial_sync_api_key', ''),
            'timeout' => get_option('testimonial_sync_api_timeout', 30),
        ];
    }

    /**
     * Fetch testimonials from Laravel API
     */
    public function fetch_testimonials()
    {
        $settings = $this->get_settings();

        if (empty($settings['endpoint'])) {
            return new WP_Error('no_endpoint', __('API endpoint not configured', 'testimonial-sync'));
        }

        $args = [
            'timeout' => $settings['timeout'],
            'headers' => [
                'Accept' => 'application/json',
            ],
        ];

        // Add API key if provided
        if (! empty($settings['api_key'])) {
            $args['headers']['Authorization'] = 'Bearer '.$settings['api_key'];
        }

        // Allow filtering of request args
        $args = apply_filters('testimonial_sync_api_request_args', $args);

        $response = wp_remote_get($settings['endpoint'], $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $status_code = wp_remote_retrieve_response_code($response);

        if ($status_code !== 200) {
            return new WP_Error(
                'api_error',
                sprintf(__('API returned status code %d', 'testimonial-sync'), $status_code)
            );
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error('json_error', __('Failed to parse API response', 'testimonial-sync'));
        }

        // Allow filtering of response data
        $data = apply_filters('testimonial_sync_api_response_data', $data);

        return $data;
    }

    /**
     * Download and save author headshot
     */
    public function download_headshot($image_url, $testimonial_id)
    {
        if (empty($image_url)) {
            return false;
        }

        // Check if we already have this image
        $existing_attachment_id = get_post_meta($testimonial_id, '_testimonial_headshot_id', true);
        if ($existing_attachment_id) {
            $existing_url = get_post_meta($existing_attachment_id, '_testimonial_source_url', true);
            if ($existing_url === $image_url) {
                return $existing_attachment_id; // Already have this image
            }
        }

        require_once ABSPATH.'wp-admin/includes/media.php';
        require_once ABSPATH.'wp-admin/includes/file.php';
        require_once ABSPATH.'wp-admin/includes/image.php';

        $tmp = download_url($image_url);

        if (is_wp_error($tmp)) {
            return false;
        }

        $file_array = [
            'name' => basename($image_url),
            'tmp_name' => $tmp,
        ];

        // If filename doesn't have an extension, add .jpg
        if (! preg_match('/\.[a-z]{3,4}$/i', $file_array['name'])) {
            $file_array['name'] .= '.jpg';
        }

        $attachment_id = media_handle_sideload($file_array, $testimonial_id);

        if (is_wp_error($attachment_id)) {
            @unlink($file_array['tmp_name']);

            return false;
        }

        // Store the source URL to avoid re-downloading
        update_post_meta($attachment_id, '_testimonial_source_url', $image_url);

        // Set as post thumbnail
        set_post_thumbnail($testimonial_id, $attachment_id);

        // Also store attachment ID separately for easy reference
        update_post_meta($testimonial_id, '_testimonial_headshot_id', $attachment_id);

        return $attachment_id;
    }

    /**
     * Save or update a testimonial from API data
     */
    public function save_testimonial($testimonial_data)
    {
        // Validate required fields
        if (empty($testimonial_data['id'])) {
            return new WP_Error('missing_id', __('Testimonial ID is required', 'testimonial-sync'));
        }

        // Check if testimonial already exists
        $existing_posts = get_posts([
            'post_type' => Testimonial_Post_Type::POST_TYPE,
            'meta_key' => '_testimonial_external_id',
            'meta_value' => $testimonial_data['id'],
            'numberposts' => 1,
        ]);

        $post_id = $existing_posts ? $existing_posts[0]->ID : 0;

        // Prepare post data
        $post_data = [
            'ID' => $post_id,
            'post_type' => Testimonial_Post_Type::POST_TYPE,
            'post_title' => ! empty($testimonial_data['title']) ? $testimonial_data['title'] : __('Testimonial', 'testimonial-sync'),
            'post_content' => ! empty($testimonial_data['content']) ? $testimonial_data['content'] : '',
            'post_status' => 'publish',
        ];

        // Allow filtering of post data
        $post_data = apply_filters('testimonial_sync_post_data', $post_data, $testimonial_data);

        // Insert or update post
        if ($post_id) {
            $result = wp_update_post($post_data);
        } else {
            $result = wp_insert_post($post_data);
        }

        if (is_wp_error($result)) {
            return $result;
        }

        $post_id = $result;

        // Update meta fields
        update_post_meta($post_id, '_testimonial_external_id', $testimonial_data['id']);

        if (! empty($testimonial_data['author_name'])) {
            update_post_meta($post_id, '_testimonial_author_name', sanitize_text_field($testimonial_data['author_name']));
        }

        if (! empty($testimonial_data['author_title'])) {
            update_post_meta($post_id, '_testimonial_author_title', sanitize_text_field($testimonial_data['author_title']));
        }

        if (! empty($testimonial_data['company'])) {
            update_post_meta($post_id, '_testimonial_company', sanitize_text_field($testimonial_data['company']));
        }

        if (isset($testimonial_data['rating'])) {
            update_post_meta($post_id, '_testimonial_rating', absint($testimonial_data['rating']));
        }

        if (! empty($testimonial_data['date_given'])) {
            update_post_meta($post_id, '_testimonial_date_given', sanitize_text_field($testimonial_data['date_given']));
        }

        if (isset($testimonial_data['featured'])) {
            update_post_meta($post_id, '_testimonial_featured', (bool) $testimonial_data['featured']);
        }

        // Handle headshot
        if (! empty($testimonial_data['headshot_url'])) {
            $this->download_headshot($testimonial_data['headshot_url'], $post_id);
        }

        // Store last sync time
        update_post_meta($post_id, '_testimonial_last_sync', current_time('mysql'));

        do_action('testimonial_sync_testimonial_saved', $post_id, $testimonial_data);

        return $post_id;
    }

    /**
     * REST API endpoint to get testimonials
     */
    public function get_testimonials_endpoint($request)
    {
        $args = [
            'post_type' => Testimonial_Post_Type::POST_TYPE,
            'posts_per_page' => $request->get_param('per_page') ?: 10,
            'paged' => $request->get_param('page') ?: 1,
        ];

        // Check for featured filter
        if ($request->get_param('featured')) {
            $args['meta_query'] = [
                [
                    'key' => '_testimonial_featured',
                    'value' => '1',
                ],
            ];
        }

        $query = new WP_Query($args);
        $testimonials = [];

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $post_id = get_the_ID();

                $testimonials[] = [
                    'id' => $post_id,
                    'title' => get_the_title(),
                    'content' => get_the_content(),
                    'author_name' => get_post_meta($post_id, '_testimonial_author_name', true),
                    'author_title' => get_post_meta($post_id, '_testimonial_author_title', true),
                    'company' => get_post_meta($post_id, '_testimonial_company', true),
                    'rating' => get_post_meta($post_id, '_testimonial_rating', true),
                    'headshot' => get_the_post_thumbnail_url($post_id, 'thumbnail'),
                    'date' => get_the_date('c'),
                ];
            }
            wp_reset_postdata();
        }

        return rest_ensure_response($testimonials);
    }
}
