<?php

/**
 * Custom Post Type for Testimonials
 */
class Testimonial_Post_Type
{
    /**
     * Post type slug
     */
    const POST_TYPE = 'testimonial';

    /**
     * Register the custom post type
     */
    public function register()
    {
        $labels = [
            'name' => _x('Testimonials', 'Post type general name', 'testimonial-sync'),
            'singular_name' => _x('Testimonial', 'Post type singular name', 'testimonial-sync'),
            'menu_name' => _x('AfterSay Testimonials', 'Admin Menu text', 'testimonial-sync'),
            'name_admin_bar' => _x('Testimonial', 'Add New on Toolbar', 'testimonial-sync'),
            'add_new' => __('Add New', 'testimonial-sync'),
            'add_new_item' => __('Add New Testimonial', 'testimonial-sync'),
            'new_item' => __('New Testimonial', 'testimonial-sync'),
            'edit_item' => __('Edit Testimonial', 'testimonial-sync'),
            'view_item' => __('View Testimonial', 'testimonial-sync'),
            'all_items' => __('All Testimonials', 'testimonial-sync'),
            'search_items' => __('Search Testimonials', 'testimonial-sync'),
            'parent_item_colon' => __('Parent Testimonials:', 'testimonial-sync'),
            'not_found' => __('No testimonials found.', 'testimonial-sync'),
            'not_found_in_trash' => __('No testimonials found in Trash.', 'testimonial-sync'),
        ];

        $args = [
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => ['slug' => 'testimonial'],
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 20,
            'menu_icon' => 'dashicons-format-quote',
            'supports' => ['title', 'editor', 'thumbnail', 'custom-fields'],
            'show_in_rest' => true,
        ];

        register_post_type(self::POST_TYPE, $args);

        // Register custom meta fields
        $this->register_meta_fields();
    }

    /**
     * Register custom meta fields
     */
    private function register_meta_fields()
    {
        // External ID from Laravel
        register_post_meta(self::POST_TYPE, '_testimonial_external_id', [
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
            'description' => 'External ID from Laravel app',
        ]);

        // Author name
        register_post_meta(self::POST_TYPE, '_testimonial_author_name', [
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
            'description' => 'Testimonial author name',
        ]);

        // Author title/position
        register_post_meta(self::POST_TYPE, '_testimonial_author_title', [
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
            'description' => 'Testimonial author title or position',
        ]);

        // Company
        register_post_meta(self::POST_TYPE, '_testimonial_company', [
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
            'description' => 'Company name',
        ]);

        // Rating (1-5)
        register_post_meta(self::POST_TYPE, '_testimonial_rating', [
            'type' => 'integer',
            'single' => true,
            'show_in_rest' => true,
            'description' => 'Rating from 1 to 5',
        ]);

        // Date given
        register_post_meta(self::POST_TYPE, '_testimonial_date_given', [
            'type' => 'string',
            'single' => true,
            'show_in_rest' => true,
            'description' => 'Date the testimonial was given',
        ]);

        // Featured flag
        register_post_meta(self::POST_TYPE, '_testimonial_featured', [
            'type' => 'boolean',
            'single' => true,
            'show_in_rest' => true,
            'description' => 'Whether the testimonial is featured',
        ]);
    }
}
