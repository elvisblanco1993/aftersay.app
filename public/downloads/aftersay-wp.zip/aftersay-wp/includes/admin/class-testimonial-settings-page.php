<?php
/**
 * Renders the Testimonial Sync Settings page and handles POST requests.
 */
class Testimonial_Settings_Page
{
    /**
     * Render settings page. Renamed to 'render' for clarity.
     */
    public function render()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        // Define the redirect URL dynamically to the current page
        $current_admin_url = add_query_arg(null, null);

        // --- 1. Handle Manual Sync Request (TRIGGER BACKGROUND SYNC) ---
        if (isset($_POST['manual_sync']) && check_admin_referer('testimonial_sync_manual')) {

            // Schedule background sync
            if (! wp_next_scheduled('testimonial_manual_sync_hook')) {
                wp_schedule_single_event(time(), 'testimonial_manual_sync_hook');
            }

            // Prepare success message
            $success_message = urlencode(__('Sync initiated! Testimonials are syncing in the background. Check the Status page for results.', 'testimonial-sync'));

            // Use proper admin URL
            $redirect_url = add_query_arg('testimonial_sync_success', $success_message, menu_page_url('testimonial-sync-settings', false));

            // Flush output buffers to prevent headers already sent
            if (ob_get_length()) {
                ob_end_clean();
            }

            // Redirect immediately
            wp_safe_redirect($redirect_url);
            exit;
        }

        // --- 2. Handle Frequency Update Request (KEPT FOR COMPLETENESS) ---
        // NOTE: While settings are usually saved by options.php, this block handles
        // the immediate rescheduling of the cron job after saving.
        if (isset($_POST['update_frequency']) && check_admin_referer('testimonial_sync_frequency')) {
            $frequency = sanitize_text_field($_POST['testimonial_sync_frequency']);
            update_option('testimonial_sync_frequency', $frequency);

            // Reschedule cron
            $timestamp = wp_next_scheduled('testimonial_sync_cron_hook');
            if ($timestamp) {
                wp_unschedule_event($timestamp, 'testimonial_sync_cron_hook');
            }
            wp_schedule_event(time(), $frequency, 'testimonial_sync_cron_hook');

            $success_message = urlencode(__('Sync frequency updated.', 'testimonial-sync'));
            $redirect_url = add_query_arg('testimonial_sync_success', $success_message, $current_admin_url);

            // wp_safe_redirect($redirect_url); // Removed for simplicity, as it can conflict with standard options.php save.
            // exit;
        }

        // --- 3. Display Redirected Messages ---
        // Display messages passed via query args on the page load.
        if (isset($_GET['testimonial_sync_success'])) {
            add_settings_error(
                'testimonial_sync_messages',
                'testimonial_sync_success',
                sanitize_text_field(urldecode($_GET['testimonial_sync_success'])),
                'success'
            );
            // Remove the query argument to clean up the URL bar
            $_SERVER['REQUEST_URI'] = remove_query_arg('testimonial_sync_success', $_SERVER['REQUEST_URI']);
        }
        if (isset($_GET['testimonial_sync_error'])) {
            add_settings_error(
                'testimonial_sync_messages',
                'testimonial_sync_error',
                sanitize_text_field(urldecode($_GET['testimonial_sync_error'])),
                'error'
            );
            // Remove the query argument to clean up the URL bar
            $_SERVER['REQUEST_URI'] = remove_query_arg('testimonial_sync_error', $_SERVER['REQUEST_URI']);
        }

        settings_errors('testimonial_sync_messages');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <form action="options.php" method="post">
                <?php
                settings_fields('testimonial_sync_settings');
        do_settings_sections('testimonial_sync_settings');
        submit_button(__('Save Settings', 'testimonial-sync'));
        ?>
            </form>
            
            <hr>
            
            <h2><?php _e('Manual Sync', 'testimonial-sync'); ?></h2>
            <p><strong><?php _e('Clicking sync will start the process in the background. Your page will reload immediately.', 'testimonial-sync'); ?></strong></p>
            
            <form method="post">
                <?php wp_nonce_field('testimonial_sync_manual'); ?>
                <button type="submit" name="manual_sync" class="button button-primary">
                    <?php _e('Sync Now (Background)', 'testimonial-sync'); ?>
                </button>
            </form>
            
            <hr>
            
            <h2><?php _e('API Response Example', 'testimonial-sync'); ?></h2>
            <p><?php _e('Your Laravel API should return JSON in one of these formats:', 'testimonial-sync'); ?></p>
            
            <h3><?php _e('Format 1: Simple Array', 'testimonial-sync'); ?></h3>
            <pre><code>[
  {
    "id": 1,
    "title": "Great Service!",
    "content": "This was an amazing experience...",
    "author_name": "John Doe",
    "author_title": "CEO",
    "company": "Acme Corp",
    "rating": 5,
    "date_given": "2024-01-15",
    "featured": true,
    "headshot_url": "https://example.com/images/john.jpg"
  }
]</code></pre>
            
            <h3><?php _e('Format 2: Laravel Pagination', 'testimonial-sync'); ?></h3>
            <pre><code>{
  "data": [
    {
      "id": 1,
      "title": "Great Service!",
      ...
    }
  ],
  "current_page": 1,
  "total": 10
}</code></pre>
            
            <h3><?php _e('Format 3: Named Key', 'testimonial-sync'); ?></h3>
            <pre><code>{
  "testimonials": [
    {
      "id": 1,
      "title": "Great Service!",
      ...
    }
  ]
}</code></pre>
        </div>
        <?php
    }
}
