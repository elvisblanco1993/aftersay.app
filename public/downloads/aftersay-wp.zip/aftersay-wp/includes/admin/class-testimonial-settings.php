<?php
/**
 * Registers all settings and provides render callbacks for fields/sections.
 */
class Testimonial_Settings
{
    /**
     * Register settings
     */
    public function register_settings()
    {
        // API Settings
        register_setting('testimonial_sync_settings', 'testimonial_sync_api_endpoint', [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => '',
        ]);

        register_setting('testimonial_sync_settings', 'testimonial_sync_api_key', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '',
        ]);

        register_setting('testimonial_sync_settings', 'testimonial_sync_api_timeout', [
            'type' => 'integer',
            'sanitize_callback' => 'absint',
            'default' => 30,
        ]);

        register_setting('testimonial_sync_settings', 'testimonial_sync_frequency', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => 'hourly',
        ]);

        // Add settings sections
        add_settings_section(
            'testimonial_sync_api_section',
            __('API Configuration', 'testimonial-sync'),
            [$this, 'render_api_section'],
            'testimonial_sync_settings'
        );

        // Add settings fields
        add_settings_field(
            'testimonial_sync_api_endpoint',
            __('API Endpoint URL', 'testimonial-sync'),
            [$this, 'render_endpoint_field'],
            'testimonial_sync_settings',
            'testimonial_sync_api_section'
        );

        add_settings_field(
            'testimonial_sync_api_key',
            __('API Key (Optional)', 'testimonial-sync'),
            [$this, 'render_api_key_field'],
            'testimonial_sync_settings',
            'testimonial_sync_api_section'
        );

        add_settings_field(
            'testimonial_sync_api_timeout',
            __('Request Timeout (seconds)', 'testimonial-sync'),
            [$this, 'render_timeout_field'],
            'testimonial_sync_settings',
            'testimonial_sync_api_section'
        );

        add_settings_field(
            'testimonial_sync_frequency',
            __('Sync Frequency', 'testimonial-sync'),
            [$this, 'render_frequency_field'],
            'testimonial_sync_settings',
            'testimonial_sync_api_section'
        );
    }

    /**
     * Render section descriptions
     */
    public function render_api_section()
    {
        echo '<p>'.__('Configure the connection to your Laravel testimonial API.', 'testimonial-sync').'</p>';
    }

    /**
     * Render field callbacks
     */
    public function render_endpoint_field()
    {
        $value = get_option('testimonial_sync_api_endpoint', '');
        echo '<input type="url" name="testimonial_sync_api_endpoint" value="'.esc_attr($value).'" class="regular-text" placeholder="https://your-laravel-app.com/api/testimonials">';
        echo '<p class="description">'.__('The full URL to your testimonials API endpoint', 'testimonial-sync').'</p>';
    }

    public function render_api_key_field()
    {
        $value = get_option('testimonial_sync_api_key', '');
        echo '<input type="password" name="testimonial_sync_api_key" value="'.esc_attr($value).'" class="regular-text">';
        echo '<p class="description">'.__('Optional: Bearer token for API authentication', 'testimonial-sync').'</p>';
    }

    public function render_timeout_field()
    {
        $value = get_option('testimonial_sync_api_timeout', 30);
        echo '<input type="number" name="testimonial_sync_api_timeout" value="'.esc_attr($value).'" min="5" max="120">';
        echo '<p class="description">'.__('Maximum time to wait for API response (5-120 seconds)', 'testimonial-sync').'</p>';
    }

    public function render_frequency_field()
    {
        $value = get_option('testimonial_sync_frequency', 'hourly');
        $schedules = wp_get_schedules(); // Though $schedules is unused, it's kept for completeness.
        ?>
        <select name="testimonial_sync_frequency">
            <option value="hourly" <?php selected($value, 'hourly'); ?>><?php _e('Hourly', 'testimonial-sync'); ?></option>
            <option value="twicedaily" <?php selected($value, 'twicedaily'); ?>><?php _e('Twice Daily', 'testimonial-sync'); ?></option>
            <option value="daily" <?php selected($value, 'daily'); ?>><?php _e('Daily', 'testimonial-sync'); ?></option>
        </select>
        <p class="description"><?php _e('How often to automatically sync testimonials', 'testimonial-sync'); ?></p>
        <?php
    }
}
