<?php
/**
 * Renders the Testimonial Sync Status page and handles log clearing.
 */
class Testimonial_Status_Page
{
    /**
     * Render status page. Renamed to 'render' for clarity.
     */
    public function render()
    {
        if (! current_user_can('manage_options')) {
            return;
        }

        $last_sync = get_option('testimonial_sync_last_sync_time');
        $last_count = get_option('testimonial_sync_last_sync_count', 0);
        $last_status = get_option('testimonial_sync_last_sync_status', 'unknown');
        $last_error = get_option('testimonial_sync_last_error', '');
        $logs = get_option('testimonial_sync_logs', []);

        // Get next scheduled sync
        $next_sync = wp_next_scheduled('testimonial_sync_cron_hook');

        // Handle clear logs
        if (isset($_POST['clear_logs']) && check_admin_referer('testimonial_sync_clear_logs')) {
            // NOTE: The original file assumes a Testimonial_Sync_Scheduler class exists.
            // We assume it is available here or is autoloaded/included elsewhere.
            $scheduler = new Testimonial_Sync_Scheduler;
            $scheduler->clear_logs();
            $logs = [];
            add_settings_error(
                'testimonial_sync_messages',
                'testimonial_sync_logs_cleared',
                __('Logs cleared', 'testimonial-sync'),
                'success'
            );
        }

        settings_errors('testimonial_sync_messages');
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <table class="widefat">
                <tr>
                    <th><?php _e('Last Sync', 'testimonial-sync'); ?></th>
                    <td><?php echo $last_sync ? esc_html($last_sync) : __('Never', 'testimonial-sync'); ?></td>
                </tr>
                <tr>
                    <th><?php _e('Last Sync Status', 'testimonial-sync'); ?></th>
                    <td>
                        <?php
                        $status_labels = [
                            'success' => __('Success', 'testimonial-sync'),
                            'partial' => __('Partial Success', 'testimonial-sync'),
                            'failed' => __('Failed', 'testimonial-sync'),
                            'unknown' => __('Unknown', 'testimonial-sync'),
                        ];
        echo esc_html($status_labels[$last_status] ?? $last_status);
        ?>
                    </td>
                </tr>
                <tr>
                    <th><?php _e('Testimonials Synced', 'testimonial-sync'); ?></th>
                    <td><?php echo esc_html($last_count); ?></td>
                </tr>
                <?php if ($last_error) { ?>
                <tr>
                    <th><?php _e('Last Error', 'testimonial-sync'); ?></th>
                    <td style="color: #d63638;"><?php echo esc_html($last_error); ?></td>
                </tr>
                <?php } ?>
                <tr>
                    <th><?php _e('Next Scheduled Sync', 'testimonial-sync'); ?></th>
                    <td><?php echo $next_sync ? esc_html(get_date_from_gmt(date('Y-m-d H:i:s', $next_sync))) : __('Not scheduled', 'testimonial-sync'); ?></td>
                </tr>
            </table>
            
            <h2><?php _e('Sync Logs', 'testimonial-sync'); ?></h2>
            
            <form method="post" style="margin-bottom: 10px;">
                <?php wp_nonce_field('testimonial_sync_clear_logs'); ?>
                <button type="submit" name="clear_logs" class="button">
                    <?php _e('Clear Logs', 'testimonial-sync'); ?>
                </button>
            </form>
            
            <?php if (! empty($logs)) { ?>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php _e('Time', 'testimonial-sync'); ?></th>
                            <th><?php _e('Level', 'testimonial-sync'); ?></th>
                            <th><?php _e('Message', 'testimonial-sync'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_reverse($logs) as $log) { ?>
                        <tr>
                            <td><?php echo esc_html($log['time']); ?></td>
                            <td><?php echo esc_html($log['level']); ?></td>
                            <td><?php echo esc_html($log['message']); ?></td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            <?php } else { ?>
                <p><?php _e('No logs available.', 'testimonial-sync'); ?></p>
            <?php } ?>
        </div>
        <?php
    }
}
