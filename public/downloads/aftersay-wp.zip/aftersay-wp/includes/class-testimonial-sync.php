<?php

/**
 * Main plugin class
 */
class Testimonial_Sync
{
    /**
     * Single instance of the class
     */
    private static $instance = null;

    /**
     * Plugin components
     */
    public $post_type;

    public $api;

    public $scheduler;

    public $admin;

    public $display;

    /**
     * Get singleton instance
     */
    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct()
    {
        // Private constructor for singleton
    }

    /**
     * Initialize plugin
     */
    public function init()
    {
        // Initialize components
        $this->post_type = new Testimonial_Post_Type;
        $this->api = new Testimonial_API;
        $this->scheduler = new Testimonial_Sync_Scheduler;
        $this->admin = new Testimonial_Admin;
        $this->display = new Testimonial_Display;

        // Hook into WordPress
        add_action('init', [$this->post_type, 'register']);
        add_action('admin_menu', [$this->admin, 'add_menu_pages']);
        add_action('admin_init', [$this->admin, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this->admin, 'enqueue_admin_assets']);
        add_action('wp_enqueue_scripts', [$this->display, 'enqueue_frontend_assets']);
        add_action('testimonial_sync_cron_hook', [$this->scheduler, 'sync_testimonials']);

        // Register shortcodes
        add_shortcode('testimonials', [$this->display, 'shortcode']);

        // Register REST API endpoints
        add_action('rest_api_init', [$this, 'register_rest_routes']);

        // Add template override support
        add_filter('template_include', [$this->display, 'template_loader']);
    }

    /**
     * Register REST API routes
     */
    public function register_rest_routes()
    {
        register_rest_route('testimonial-sync/v1', '/sync', [
            'methods' => 'POST',
            'callback' => [$this->scheduler, 'manual_sync'],
            'permission_callback' => function () {
                return current_user_can('manage_options');
            },
        ]);

        register_rest_route('testimonial-sync/v1', '/testimonials', [
            'methods' => 'GET',
            'callback' => [$this->api, 'get_testimonials_endpoint'],
            'permission_callback' => '__return_true',
        ]);
    }
}
