<?php
/**
 * Template: Single Testimonial Page
 *
 * This template can be overridden by copying it to:
 * your-theme/testimonial-sync/single-testimonial.php
 */
// get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        
        <?php while (have_posts()) {
            the_post(); ?>
            
            <article id="post-<?php the_ID(); ?>" <?php post_class('testimonial-single'); ?>>
                
                <header class="entry-header testimonial-single-header">
                    
                    <?php if ($rating = testimonial_get_rating()) { ?>
                        <div class="testimonial-rating-wrapper">
                            <?php echo Testimonial_Display::get_rating_html($rating); ?>
                        </div>
                    <?php } ?>
                    
                    <?php if (get_the_title()) { ?>
                        <h1 class="entry-title testimonial-single-title"><?php the_title(); ?></h1>
                    <?php } ?>
                    
                </header>
                
                <div class="testimonial-single-body">
                    
                    <div class="testimonial-quote-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path d="M6 17h3l2-4V7H5v6h3zm8 0h3l2-4V7h-6v6h3z"/>
                        </svg>
                    </div>
                    
                    <div class="entry-content testimonial-single-content">
                        <?php the_content(); ?>
                    </div>
                    
                </div>
                
                <footer class="entry-footer testimonial-single-footer">
                    
                    <div class="testimonial-author-card">
                        
                        <?php if (has_post_thumbnail()) { ?>
                            <div class="testimonial-author-avatar">
                                <?php testimonial_headshot('medium'); ?>
                            </div>
                        <?php } ?>
                        
                        <div class="testimonial-author-details">
                            <?php if ($author_name = testimonial_get_author_name()) { ?>
                                <h2 class="testimonial-author-name"><?php echo esc_html($author_name); ?></h2>
                            <?php } ?>
                            
                            <?php
                            $title = testimonial_get_author_title();
            $company = testimonial_get_company();
            if ($title || $company) {
                ?>
                                <p class="testimonial-author-position">
                                    <?php
                    if ($title && $company) {
                        printf(__('%s at %s', 'testimonial-sync'), esc_html($title), '<strong>'.esc_html($company).'</strong>');
                    } elseif ($title) {
                        echo esc_html($title);
                    } else {
                        echo '<strong>'.esc_html($company).'</strong>';
                    }
                ?>
                                </p>
                            <?php } ?>
                            
                            <?php if ($date_given = testimonial_get_date_given()) { ?>
                                <p class="testimonial-date-given">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                    </svg>
                                    <?php echo esc_html(date_i18n(get_option('date_format'), strtotime($date_given))); ?>
                                </p>
                            <?php } ?>
                        </div>
                        
                    </div>
                    
                    <?php if (testimonial_is_featured()) { ?>
                        <div class="testimonial-featured-indicator">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                            </svg>
                            <span><?php _e('Featured Testimonial', 'testimonial-sync'); ?></span>
                        </div>
                    <?php } ?>
                    
                </footer>
                
                <?php
                // Navigation to other testimonials
                $prev_post = get_previous_post();
            $next_post = get_next_post();

            if ($prev_post || $next_post) {
                ?>
                    <nav class="testimonial-navigation">
                        <?php if ($prev_post) { ?>
                            <a href="<?php echo get_permalink($prev_post); ?>" class="testimonial-nav-previous">
                                <span class="nav-label"><?php _e('Previous Testimonial', 'testimonial-sync'); ?></span>
                                <span class="nav-title"><?php echo get_the_title($prev_post); ?></span>
                            </a>
                        <?php } ?>
                        
                        <?php if ($next_post) { ?>
                            <a href="<?php echo get_permalink($next_post); ?>" class="testimonial-nav-next">
                                <span class="nav-label"><?php _e('Next Testimonial', 'testimonial-sync'); ?></span>
                                <span class="nav-title"><?php echo get_the_title($next_post); ?></span>
                            </a>
                        <?php } ?>
                    </nav>
                <?php } ?>
                
            </article>
            
        <?php } ?>
        
    </main>
</div>

<?php
// get_sidebar();
// get_footer();
