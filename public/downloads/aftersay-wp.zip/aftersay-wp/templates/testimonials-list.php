<?php
/**
 * Template: List Layout
 *
 * This template can be overridden by copying it to:
 * your-theme/testimonial-sync/testimonials-list.php
 */
if (! defined('ABSPATH')) {
    exit;
}
?>

<div class="testimonials-wrapper testimonials-layout-list">
    <?php while ($query->have_posts()) {
        $query->the_post(); ?>
        <article class="testimonial-item" id="testimonial-<?php the_ID(); ?>">
            
            <?php if (has_post_thumbnail()) { ?>
                <div class="testimonial-headshot-wrapper">
                    <?php testimonial_headshot('thumbnail'); ?>
                </div>
            <?php } ?>
            
            <div class="testimonial-content-wrapper">
                
                <?php if ($rating = testimonial_get_rating()) { ?>
                    <div class="testimonial-rating-wrapper">
                        <?php echo Testimonial_Display::get_rating_html($rating); ?>
                    </div>
                <?php } ?>
                
                <?php if (get_the_title()) { ?>
                    <h3 class="testimonial-title"><?php the_title(); ?></h3>
                <?php } ?>
                
                <div class="testimonial-content">
                    <?php the_content(); ?>
                </div>
                
                <div class="testimonial-author">
                    <?php if ($author_name = testimonial_get_author_name()) { ?>
                        <span class="testimonial-author-name"><?php echo esc_html($author_name); ?></span>
                    <?php } ?>
                    
                    <?php
                        $title = testimonial_get_author_title();
        $company = testimonial_get_company();
        if ($title || $company) {
            ?>
                        <span class="testimonial-author-meta">
                            <?php
                    if ($title && $company) {
                        printf(__('%s at %s', 'testimonial-sync'), esc_html($title), esc_html($company));
                    } elseif ($title) {
                        echo esc_html($title);
                    } else {
                        echo esc_html($company);
                    }
            ?>
                        </span>
                    <?php } ?>
                </div>
                
                <?php if (testimonial_is_featured()) { ?>
                    <span class="testimonial-featured-badge"><?php _e('Featured', 'testimonial-sync'); ?></span>
                <?php } ?>
                
            </div>
            
        </article>
    <?php } ?>
</div>