<?php
/**
 * Template: Testimonials Archive
 *
 * This template can be overridden by copying it to:
 * your-theme/testimonial-sync/archive-testimonial.php
 */
get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main">
        
        <header class="page-header">
            <h1 class="page-title"><?php _e('Testimonials', 'testimonial-sync'); ?></h1>
            <?php
            $description = get_the_archive_description();
if ($description) {
    echo '<div class="archive-description">'.$description.'</div>';
}
?>
        </header>
        
        <?php if (have_posts()) { ?>
            
            <div class="testimonials-archive-wrapper">
                <?php while (have_posts()) {
                    the_post(); ?>
                    
                    <article id="post-<?php the_ID(); ?>" <?php post_class('testimonial-archive-item'); ?>>
                        
                        <div class="testimonial-archive-content">
                            
                            <?php if (has_post_thumbnail()) { ?>
                                <div class="testimonial-headshot-wrapper">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php testimonial_headshot('thumbnail'); ?>
                                    </a>
                                </div>
                            <?php } ?>
                            
                            <div class="testimonial-text">
                                
                                <?php if ($rating = testimonial_get_rating()) { ?>
                                    <div class="testimonial-rating-wrapper">
                                        <?php echo Testimonial_Display::get_rating_html($rating); ?>
                                    </div>
                                <?php } ?>
                                
                                <?php if (get_the_title()) { ?>
                                    <h2 class="testimonial-title">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h2>
                                <?php } ?>
                                
                                <div class="testimonial-excerpt">
                                    <?php the_excerpt(); ?>
                                </div>
                                
                                <div class="testimonial-author">
                                    <?php testimonial_author_byline(); ?>
                                </div>
                                
                                <a href="<?php the_permalink(); ?>" class="testimonial-read-more">
                                    <?php _e('Read full testimonial', 'testimonial-sync'); ?> →
                                </a>
                                
                            </div>
                            
                        </div>
                        
                    </article>
                    
                <?php } ?>
            </div>
            
            <?php
            // Pagination
            the_posts_pagination([
                    'mid_size' => 2,
                    'prev_text' => __('← Previous', 'testimonial-sync'),
                    'next_text' => __('Next →', 'testimonial-sync'),
            ]);
            ?>
            
        <?php } else { ?>
            
            <p><?php _e('No testimonials found.', 'testimonial-sync'); ?></p>
            
        <?php } ?>
        
    </main>
</div>

<?php
get_sidebar();
get_footer();
