# Developer Guide - Testimonial Sync

This guide explains how to customize and extend the Testimonial Sync plugin.

## Architecture Overview

```
testimonial-sync/
├── testimonial-sync.php          # Main plugin file
├── includes/
│   ├── class-testimonial-sync.php           # Main plugin class
│   ├── class-testimonial-post-type.php      # Custom post type
│   ├── class-testimonial-api.php            # API communication
│   ├── class-testimonial-sync-scheduler.php # Sync scheduler
│   ├── class-testimonial-admin.php          # Admin interface
│   ├── class-testimonial-display.php        # Frontend display
│   └── testimonial-functions.php            # Helper functions
├── templates/
│   ├── testimonials-list.php      # List layout template
│   ├── testimonials-grid.php      # Grid layout template
│   └── single-testimonial.php     # Single testimonial page
└── assets/
    ├── css/
    │   ├── frontend.css           # Frontend styles
    │   └── admin.css              # Admin styles
    └── js/
        ├── frontend.js            # Frontend JavaScript
        └── admin.js               # Admin JavaScript
```

## Custom Post Type

The plugin registers a `testimonial` custom post type with the following meta fields:

- `_testimonial_external_id` - ID from Laravel app
- `_testimonial_author_name` - Author name
- `_testimonial_author_title` - Author title/position
- `_testimonial_company` - Company name
- `_testimonial_rating` - Rating (1-5)
- `_testimonial_date_given` - Date testimonial was given
- `_testimonial_featured` - Featured flag
- `_testimonial_headshot_id` - Attachment ID of headshot

## Creating Custom Templates

### Method 1: Theme Override

Copy any template from `testimonial-sync/templates/` to your theme:

```
your-theme/testimonial-sync/testimonials-list.php
```

### Method 2: Custom Layout

Create a new layout file:

```php
// your-theme/testimonial-sync/testimonials-custom.php
<?php
if (!defined('ABSPATH')) exit;
?>
<div class="my-custom-testimonials">
    <?php while ($query->have_posts()) : $query->the_post(); ?>
        <div class="my-testimonial">
            <h3><?php the_title(); ?></h3>
            <?php the_content(); ?>
            <p>- <?php testimonial_author_byline(); ?></p>
        </div>
    <?php endwhile; ?>
</div>
```

Use it: `[testimonials layout="custom"]`

## Building Custom Displays

### Example: Featured Testimonials Widget

```php
<?php
// Get 3 random featured testimonials
$args = array(
    'post_type' => 'testimonial',
    'posts_per_page' => 3,
    'orderby' => 'rand',
    'meta_query' => array(
        array(
            'key' => '_testimonial_featured',
            'value' => '1',
        ),
    ),
);

$testimonials = new WP_Query($args);

if ($testimonials->have_posts()) :
    while ($testimonials->have_posts()) : $testimonials->the_post();
        ?>
        <div class="widget-testimonial">
            <?php if (has_post_thumbnail()) : ?>
                <?php testimonial_headshot('thumbnail'); ?>
            <?php endif; ?>
            
            <blockquote>
                <?php the_content(); ?>
            </blockquote>
            
            <cite><?php testimonial_author_byline(); ?></cite>
            
            <?php if ($rating = testimonial_get_rating()) : ?>
                <?php echo Testimonial_Display::get_rating_html($rating); ?>
            <?php endif; ?>
        </div>
        <?php
    endwhile;
    wp_reset_postdata();
endif;
```

### Example: Testimonial Slider

```php
<div class="testimonial-slider">
    <?php
    $testimonials = testimonial_get_featured(5);
    
    if ($testimonials->have_posts()) :
        while ($testimonials->have_posts()) : $testimonials->the_post();
            ?>
            <div class="slide">
                <div class="slide-content">
                    <?php the_content(); ?>
                </div>
                <div class="slide-author">
                    <?php testimonial_headshot('medium'); ?>
                    <div>
                        <strong><?php testimonial_author_name(); ?></strong>
                        <span><?php testimonial_author_title(); ?></span>
                    </div>
                </div>
            </div>
            <?php
        endwhile;
        wp_reset_postdata();
    endif;
    ?>
</div>
```

## Hooks Reference

### Action Hooks

#### testimonial_sync_testimonial_saved

Fires after a testimonial is saved or updated.

```php
add_action('testimonial_sync_testimonial_saved', function($post_id, $testimonial_data) {
    // Send notification
    // Update related data
    // Custom processing
}, 10, 2);
```

#### testimonial_sync_completed

Fires after sync completes.

```php
add_action('testimonial_sync_completed', function($synced_count, $error_count) {
    // Log to external service
    // Send admin notification
    error_log("Synced {$synced_count} testimonials with {$error_count} errors");
}, 10, 2);
```

#### testimonial_sync_log

Fires when plugin logs a message.

```php
add_action('testimonial_sync_log', function($message, $level) {
    // Send to external logging service
    if ($level === 'error') {
        // Alert admins
    }
}, 10, 2);
```

### Filter Hooks

#### testimonial_sync_api_request_args

Modify the API request arguments before sending.

```php
add_filter('testimonial_sync_api_request_args', function($args) {
    // Add custom headers
    $args['headers']['X-Custom-Header'] = 'value';
    
    // Increase timeout
    $args['timeout'] = 60;
    
    // Add query parameters
    $args['body'] = array('page' => 1, 'per_page' => 100);
    
    return $args;
});
```

#### testimonial_sync_api_response_data

Transform API response data before processing.

```php
add_filter('testimonial_sync_api_response_data', function($data) {
    // Handle custom API structure
    if (isset($data['results'])) {
        return $data['results'];
    }
    
    // Transform field names
    foreach ($data as &$testimonial) {
        if (isset($testimonial['user_name'])) {
            $testimonial['author_name'] = $testimonial['user_name'];
        }
    }
    
    return $data;
});
```

#### testimonial_sync_post_data

Modify post data before creating/updating testimonial.

```php
add_filter('testimonial_sync_post_data', function($post_data, $testimonial_data) {
    // Set custom post status
    if (isset($testimonial_data['approved']) && !$testimonial_data['approved']) {
        $post_data['post_status'] = 'pending';
    }
    
    // Customize title format
    $post_data['post_title'] = sprintf(
        '%s - %s',
        $testimonial_data['author_name'],
        $testimonial_data['company']
    );
    
    return $post_data;
}, 10, 2);
```

#### testimonial_sync_query_args

Modify testimonial query arguments.

```php
add_filter('testimonial_sync_query_args', function($args, $atts) {
    // Filter by rating
    if (isset($atts['min_rating'])) {
        $args['meta_query'][] = array(
            'key' => '_testimonial_rating',
            'value' => intval($atts['min_rating']),
            'compare' => '>=',
            'type' => 'NUMERIC',
        );
    }
    
    return $args;
}, 10, 2);
```

#### testimonial_sync_extract_testimonials

Handle custom API response structures.

```php
add_filter('testimonial_sync_extract_testimonials', function($data) {
    // Your API returns testimonials nested differently
    if (isset($data['response']['items'])) {
        return $data['response']['items'];
    }
    
    return $data;
});
```

## Custom API Authentication

### OAuth Example

```php
add_filter('testimonial_sync_api_request_args', function($args) {
    $token = get_option('my_oauth_token');
    
    if ($token) {
        $args['headers']['Authorization'] = 'Bearer ' . $token;
    }
    
    return $args;
});
```

### Custom Header Authentication

```php
add_filter('testimonial_sync_api_request_args', function($args) {
    $args['headers']['X-API-Key'] = get_option('testimonial_sync_api_key');
    $args['headers']['X-API-Secret'] = get_option('testimonial_sync_api_secret');
    
    return $args;
});
```

## Programmatic Sync

Trigger sync programmatically:

```php
// Get scheduler instance
$scheduler = new Testimonial_Sync_Scheduler();

// Run sync
$result = $scheduler->sync_testimonials();

if (is_wp_error($result)) {
    echo 'Sync failed: ' . $result->get_error_message();
} else {
    echo "Synced {$result['synced']} testimonials";
}
```

## Database Queries

### Get testimonials by rating

```php
$args = array(
    'post_type' => 'testimonial',
    'meta_query' => array(
        array(
            'key' => '_testimonial_rating',
            'value' => 5,
            'compare' => '=',
            'type' => 'NUMERIC',
        ),
    ),
);

$five_star = new WP_Query($args);
```

### Get testimonials by company

```php
$args = array(
    'post_type' => 'testimonial',
    'meta_query' => array(
        array(
            'key' => '_testimonial_company',
            'value' => 'Acme Corp',
            'compare' => '=',
        ),
    ),
);

$company_testimonials = new WP_Query($args);
```

## REST API Usage

### Get testimonials via JavaScript

```javascript
fetch('/wp-json/testimonial-sync/v1/testimonials?featured=1&per_page=5')
    .then(response => response.json())
    .then(data => {
        data.forEach(testimonial => {
            console.log(testimonial.author_name, testimonial.rating);
        });
    });
```

### Trigger sync via REST API

```javascript
fetch('/wp-json/testimonial-sync/v1/sync', {
    method: 'POST',
    headers: {
        'X-WP-Nonce': wpApiSettings.nonce,
    },
})
.then(response => response.json())
.then(data => {
    console.log(data.message);
});
```

## Performance Optimization

### Caching

```php
// Cache featured testimonials for 1 hour
function get_cached_featured_testimonials() {
    $cache_key = 'featured_testimonials';
    $testimonials = get_transient($cache_key);
    
    if (false === $testimonials) {
        $testimonials = testimonial_get_featured(5);
        set_transient($cache_key, $testimonials, HOUR_IN_SECONDS);
    }
    
    return $testimonials;
}

// Clear cache when testimonial is saved
add_action('testimonial_sync_testimonial_saved', function($post_id) {
    delete_transient('featured_testimonials');
});
```

### Lazy Loading Images

```php
add_filter('wp_get_attachment_image_attributes', function($attr, $attachment) {
    $attr['loading'] = 'lazy';
    return $attr;
}, 10, 2);
```

## Troubleshooting

### Enable Debug Logging

```php
// In wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

### Test API Connection

```php
$api = new Testimonial_API();
$result = $api->fetch_testimonials();

if (is_wp_error($result)) {
    echo 'Error: ' . $result->get_error_message();
} else {
    echo 'Success! Found ' . count($result) . ' testimonials';
}
```

### Clear and Reschedule Cron

```php
// Clear existing schedule
wp_clear_scheduled_hook('testimonial_sync_cron_hook');

// Reschedule
wp_schedule_event(time(), 'hourly', 'testimonial_sync_cron_hook');
```

## Best Practices

1. **Always use helper functions** instead of accessing meta fields directly
2. **Use template overrides** in your theme rather than modifying plugin files
3. **Test API changes** before deploying to production
4. **Monitor sync logs** regularly for errors
5. **Cache testimonials** on high-traffic sites
6. **Use filters** to customize behavior instead of editing core files
7. **Validate and sanitize** all user inputs in custom code

## Support

For additional help, check the main README.md or contact support.