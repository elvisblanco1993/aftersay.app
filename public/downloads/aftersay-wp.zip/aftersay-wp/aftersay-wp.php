<?php

/**
 * Plugin Name: AfterSay Testimonial Sync
 * Plugin URI: https://aftersay.app/wp-plugin
 * Description: Syncs testimonials from aftersay.app and displays them with customizable templates
 * Version: 1.0.0
 * Author: Elvis Blanco Gonzalez
 * Author URI: https://aftersay.app
 * License: MIT
 * License URI: https://mit-license.org
 * Text Domain: testimonial-sync
 * Domain Path: /languages
 */

// Exit if accessed directly
if (! defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('TESTIMONIAL_SYNC_VERSION', '1.0.0');
define('TESTIMONIAL_SYNC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('TESTIMONIAL_SYNC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('TESTIMONIAL_SYNC_PLUGIN_FILE', __FILE__);

// Require dependencies
require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/class-testimonial-sync.php';
require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/class-testimonial-post-type.php';
require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/class-testimonial-api.php';
require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/class-testimonial-sync-scheduler.php';

// --- START: NEW ADMIN FILE REQUIRES ---
// Since the original class was split into four files:
require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/class-testimonial-admin.php';
require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/admin/class-testimonial-settings.php';
require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/admin/class-testimonial-settings-page.php';
require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/admin/class-testimonial-status-page.php';
// --- END: NEW ADMIN FILE REQUIRES ---

require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/class-testimonial-display.php';
require_once TESTIMONIAL_SYNC_PLUGIN_DIR.'includes/testimonial-functions.php';

/**
 * Initialize the plugin
 */
function testimonial_sync_init()
{
    $plugin = Testimonial_Sync::get_instance();
    $plugin->init();
}
add_action('plugins_loaded', 'testimonial_sync_init');

/**
 * Activation hook
 */
function testimonial_sync_activate()
{
    // Register post type for flush_rewrite_rules to work
    $post_type = new Testimonial_Post_Type;
    $post_type->register();

    // Flush rewrite rules
    flush_rewrite_rules();

    // Schedule cron job
    if (! wp_next_scheduled('testimonial_sync_cron_hook')) {
        wp_schedule_event(time(), 'hourly', 'testimonial_sync_cron_hook');
    }
}
register_activation_hook(__FILE__, 'testimonial_sync_activate');

/**
 * Deactivation hook
 */
function testimonial_sync_deactivate()
{
    // Clear scheduled cron
    $timestamp = wp_next_scheduled('testimonial_sync_cron_hook');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'testimonial_sync_cron_hook');
    }

    // Flush rewrite rules
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'testimonial_sync_deactivate');

/**
 * Hook the manual sync action to the actual sync function
 */
function testimonial_run_manual_sync()
{
    // This function will run when the 'testimonial_manual_sync_hook' is triggered by WP-Cron
    $scheduler = new Testimonial_Sync_Scheduler;
    $scheduler->sync_testimonials();
}
add_action('testimonial_manual_sync_hook', 'testimonial_run_manual_sync');
